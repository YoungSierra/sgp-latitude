<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <?php echo $__env->make('partials.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  App CSS (Do not remove) -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    </head>
    <body class="c-app flex-row align-items-center">
        <main class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!-- App JS (Do not remove) -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/layouts/auth.blade.php ENDPATH**/ ?>