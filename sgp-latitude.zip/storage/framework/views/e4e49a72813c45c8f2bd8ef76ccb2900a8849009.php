<?php $__env->startSection('title', 'Editar rol'); ?>

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('roles.edit')); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col">
			<?php if(session('message')): ?>
			    <div class="alert alert-success" role="alert">
			    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					  	<i class="fas fa-times-circle"></i>
					</button>
			        <?php echo e(session('message')); ?>

			    </div>
			<?php endif; ?>
		</div>
	</div>
	<form method="POST" action="<?php echo e(route('roles.update', $rol->id)); ?>">
		<?php echo method_field('PUT'); ?>
    	<?php echo csrf_field(); ?>
	    <div class="row justify-content-center">
	        <div class="col-4">
	            <div class="card shadow-sm">
	                <div class="card-header">
	                    <i class="fas fa-edit"></i> Editar Rol
	                </div>
	                <div class="card-body">
	                    <div class="form-group">
	                        <label for="name">Nombre</label>
	                        <input
		                        id="name"
		                        name="name"
		                        type="text"
		                        placeholder="Nombre"
		                        value="<?php echo e($rol->name); ?>"
		                        class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
	                        >
	                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                            <span class="invalid-feedback" role="alert">
	                                <strong><?php echo e($message); ?></strong>
	                            </span>
	                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                    </div>
	                    <hr>
	                    <div class="row">
    						<div class="col">
    							<a role="button"
    								class="btn btn-secondary btn-block"
    								href="<?php echo e(route('roles.index')); ?>"
    							>
									<i class="fas fa-undo-alt"></i> Regresar
								</a>
    						</div>
    						<div class="col">
    							<button class="btn btn-primary btn-block" type="submit">
									<i class="fas fa-check"></i> Actualizar
								</button>
    						</div>
    					</div>
	                </div>
	            </div>
	        </div>
	        <div class="col-3">
	            <div class="card shadow-sm">
	                <div class="card-header">
	                    <i class="fas fa-list"></i> Permisos del Rol
	                </div>
	                <div class="card-body">
	            		<?php if($permissions->count()): ?>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group form-check">
                                    <?php echo e(html()->label(html()->checkbox('permissions[]', in_array($permission->name, $rol->permissions->pluck('name')->all()), $permission->name)->id('permission-'.$permission->id) . ' ' . $permission->name)->for('permission-'.$permission->id)); ?>

                                    <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                            <span class="invalid-feedback" role="alert">
			                                <strong><?php echo e($message); ?></strong>
			                            </span>
			                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
	        		</div>
	            </div>
	        </div>
	    </div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/roles/edit.blade.php ENDPATH**/ ?>