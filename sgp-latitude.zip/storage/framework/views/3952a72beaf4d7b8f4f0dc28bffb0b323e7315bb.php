<?php $__env->startSection('title', 'Crear Usuario'); ?>

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('users.create')); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col">
			<?php if(session('message')): ?>
			    <div class="alert alert-success" role="alert">
			    	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					  	<i class="fas fa-times-circle"></i>
					</button>
			        <?php echo e(session('message')); ?>

			    </div>
			<?php endif; ?>
		</div>
	</div>
    <div class="row justify-content-center">
        <div class="col-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <i class="fas fa-plus-circle"></i> Nuevo Usuario
                </div>
                <div class="card-body">
                	<form method="POST" action="<?php echo e(route('users.store')); ?>">
						<?php echo method_field('POST'); ?>
				    	<?php echo csrf_field(); ?>
	                	<div class="row">
	        				<div class="col">
			                    <div class="form-group">
			                        <label for="first_name">Nombres</label>
			                        <input
				                        type="text"
				                        id="first_name"
				                        name="first_name"
				                        placeholder="Nombres"
				                        autocomplete="off"
				                        value="<?php echo e(old('first_name')); ?>"
				                        class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                    <div class="form-group">
			                        <label for="email">Correo</label>
			                        <input
				                        id="email"
				                        name="email"
				                        type="text"
				                        placeholder="user@example.com"
				                        autocomplete="off"
				                        value="<?php echo e(old('email')); ?>"
				                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                    <div class="form-group">
			                        <label for="password">Contraseña</label>
			                        <input
				                        id="password"
				                        name="password"
				                        type="password"
				                        placeholder="****"
				                        autocomplete="off"
				                        value="<?php echo e(old('password')); ?>"
				                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                    <div class="form-group">
			                        <label for="rol">Rol</label>
			                        <select
				                        id="rol"
				                        name="rol"
				                        class="form-control <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        	<option value="">Seleccionar</option>
			                        	<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								      		<option value="<?php echo e($rol->name); ?>" <?php echo e((old('rol') == $rol->id) ? 'selected' : ''); ?>>
								      			<?php echo e($rol->name); ?>

								      		</option>
			                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    </select>
								    <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                </div>
			                <div class="col">
			                    <div class="form-group">
			                        <label for="last_name">Apellidos</label>
			                        <input
				                        id="last_name"
				                        name="last_name"
				                        type="text"
				                        autocomplete="off"
				                        placeholder="Apellidos"
				                        value="<?php echo e(old('last_name')); ?>"
				                        class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                    <div class="form-group">
			                        <label for="status">Estado</label>
			                        <select
			                        	id="status"
				                        name="status"
				                        class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
								      	<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								      		<option value="<?php echo e($key); ?>" <?php echo e((old('status') == $key) ? 'selected' : ''); ?>>
								      			<?php echo e($value); ?>

								      		</option>
			                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    </select>
								    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                    <div class="form-group">
			                        <label for="password_confirmation">Confirmar Contraseña</label>
			                        <input
				                        id="password_confirmation"
				                        name="password_confirmation"
				                        type="password"
				                        placeholder="****"
				                        autocomplete="off"
				                        value="<?php echo e(old('password_confirmation')); ?>"
				                        class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                    <div class="form-group">
			                        <label for="associate_id">Asociado</label>
			                        <select
				                        id="associate_id"
				                        name="associate_id"
				                        class="form-control <?php $__errorArgs = ['associate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			                        >
			                        	<option value="">Seleccionar</option>
			                        	<?php $__currentLoopData = $associates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $associate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								      		<option value="<?php echo e($associate->id); ?>" <?php echo e((old('associate_id') == $associate->id) ? 'selected' : ''); ?>>
								      			<?php echo e($associate->first_name); ?> <?php echo e($associate->last_name); ?>

								      		</option>
			                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    </select>
								    <?php $__errorArgs = ['associate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <span class="invalid-feedback" role="alert">
	                                        <strong><?php echo e($message); ?></strong>
	                                    </span>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                    </div>
			                </div>
			            </div>
			            <div class="row">
							<div class="col">
								<a class="btn btn-secondary btn-block" role="button" href="<?php echo e(route('users.index')); ?>">
									<i class="fas fa-undo-alt"></i> Regresar
								</a>
							</div>
							<div class="col">
								<button class="btn btn-primary btn-block" type="submit">
									<i class="far fa-save"></i> Guardar
								</button>
							</div>
						</div>
					</form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/users/create.blade.php ENDPATH**/ ?>