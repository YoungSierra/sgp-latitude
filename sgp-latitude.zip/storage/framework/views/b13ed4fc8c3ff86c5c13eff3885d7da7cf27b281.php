<p class="text-center mt-3">
    Si tienes problemas para iniciar sesión, comunícate con el administrador general - <strong>email@latitude.com</strong>
</p><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/partials/text_support.blade.php ENDPATH**/ ?>