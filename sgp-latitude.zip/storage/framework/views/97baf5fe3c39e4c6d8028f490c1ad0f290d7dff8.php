

<?php if(Auth::user()->hasRole('superadministrador') || Auth::user()->hasRole('administrador')  ): ?>
<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('projects.index')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
		<div class="col">
			<div class="card">
				<div class="card-header px-3 py-2">
					<div class="row">
						<div class="col-10">
							<h2 class="mb-0">
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-shield-check" viewBox="0 0 16 16">
								<path d="M6.5 1A1.5 1.5 0 0 0 5 2.5V3H1.5A1.5 1.5 0 0 0 0 4.5v8A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-8A1.5 1.5 0 0 0 14.5 3H11v-.5A1.5 1.5 0 0 0 9.5 1h-3zm0 1h3a.5.5 0 0 1 .5.5V3H6v-.5a.5.5 0 0 1 .5-.5zm1.886 6.914L15 7.151V12.5a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5V7.15l6.614 1.764a1.5 1.5 0 0 0 .772 0zM1.5 4h13a.5.5 0 0 1 .5.5v1.616L8.129 7.948a.5.5 0 0 1-.258 0L1 6.116V4.5a.5.5 0 0 1 .5-.5z"/>
					            </svg> Proyectos
							</h2>
						</div>
						<div class="col-2">
							<?php if(auth()->user()->can('add_project')): ?>
								<a class="btn btn-success btn-block" role="button" href="<?php echo e(route('projects.create')); ?>">
									<i class="fas fa-plus-circle"></i> Nuevo
								</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col">
						<?php if(session('message')): ?>
							<div class="alert alert-success" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<i class="fas fa-times-circle"></i>
								</button>
								<?php echo e(session('message')); ?>

							</div>
						<?php endif; ?>
					</div>
				</div>

				<div class="card-body p-0">
					<table class="table table-striped table-bordered table-condensed table-hover table-sm mb-0">
						<thead>
							<tr class="text-center text-white bg-secondary">
								<th>Nombre</th>
								<th>Valor contrato</th>
								<th>Tiempo</th>
								<th>Estado</th>
								<th>Creado</th>
								<th>Actualizado</th>
								<th width="120px">Acción</th>
							</tr>
						</thead>
						<tbody class="mb-0">
							<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="text-center">
									<td><?php echo e($project->name); ?></td>
									<td>$ <?php echo e($project->valor); ?></td>
									<td><?php echo e($project->tiempo); ?></td>
									<?php if($project->status == '1'): ?>
										<td><span class="badge badge-success">Activo</span></td>
									<?php else: ?>
										<td><span class="badge badge-danger">Inactivo</span></td>
									<?php endif; ?>
									<td><span class="badge badge-primary"><?php echo e($project->created_at); ?></span></td>
									<td><span class="badge badge-info"><?php echo e($project->updated_at); ?></span></td>
									<td>
										<div class="btn-group btn-group-sm" role="group" aria-label="actions-policies">
											<div class="btn-group btn-group-sm" role="group" aria-label="actions-policies">
												<?php if(auth()->user()->can('show_project')): ?>
													<a
														rol="button"
														class="btn btn-outline-info rounded-0"
														href="<?php echo e(route('projects.show' , $project->id )); ?>"
													>
														<i class="fas fa-eye"></i>
													</a>
												<?php endif; ?>
												<?php if(auth()->user()->can('edit_project')): ?>
													<a
														rol="button"
														class="btn btn-outline-success rounded-0"
														href="<?php echo e(route('projects.edit' , $project->id )); ?>"
													>
														<i class="fas fa-edit"></i>
													</a>
												<?php endif; ?>
												<?php if(auth()->user()->can('delete_project')): ?>
													<form id="delete_<?php echo e($project->id); ?>"
														method="post"
														action="<?php echo e(route('projects.destroy' , $project->id )); ?>"
													>
								                    	<?php echo csrf_field(); ?>
								                    	<?php echo method_field('DELETE'); ?>
								                    	<button
								                    		type="button" onclick="validarDelProject(<?php echo e($project->id); ?>);"
								                    		class="btn btn-sm btn-outline-danger rounded-0"	>
								                    		<i class="far fa-trash-alt"></i>
								                    	</button>
								                  	</form>
												<?php endif; ?>
											</div>
										</div>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('asociado')): ?>

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render('projects.index' )); ?> 

<?php $__env->startSection('content'); ?>
    <div class="row">
		<div class="col">
			<div class="card">

				<div class="card-header px-3 py-2">
					<div class="row">
						<div class="col-12">
							<h2 class="mb-0">
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-shield-check" viewBox="0 0 16 16">
								<path d="M6.5 1A1.5 1.5 0 0 0 5 2.5V3H1.5A1.5 1.5 0 0 0 0 4.5v8A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-8A1.5 1.5 0 0 0 14.5 3H11v-.5A1.5 1.5 0 0 0 9.5 1h-3zm0 1h3a.5.5 0 0 1 .5.5V3H6v-.5a.5.5 0 0 1 .5-.5zm1.886 6.914L15 7.151V12.5a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5V7.15l6.614 1.764a1.5 1.5 0 0 0 .772 0zM1.5 4h13a.5.5 0 0 1 .5.5v1.616L8.129 7.948a.5.5 0 0 1-.258 0L1 6.116V4.5a.5.5 0 0 1 .5-.5z"/>
					            </svg> Proyectos en los que usted participa: <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?>

							</h2>
						</div>
					</div>
				</div>

				<div class="card-body p-0">
					<table class="table table-striped table-bordered table-condensed table-hover table-sm mb-0">
						<thead>
							<tr class="text-center text-white bg-secondary">
								<th>Proyecto</th>
								<th>Neto Operacional</th>
								<th>PART %</th>
								<th>PART $</th>
								<th>Fase 1 %</th>
								<th>Fase 2 %</th>
								<th>Fase 3 %</th>
								<th title="Total fases %">Tot Fases %</th>
								<th title="Participación final %">P Final %</th>
								<th title="Participación final $">P Final $</th>
							</tr>
						</thead>
						<tbody class="mb-0">
							<?php
								$totpart = 0; 
								$sum = 0; 
							?>
							
							<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="text-center">
									<td class="text-left"><?php echo e($project->name); ?></td>
									<td class="text-right">$ <?php echo e($project->costosexternos); ?></td>
									<td><?php echo e($project->porcentaje); ?> %</td>
									<td class="text-right">$ <?php echo e($project->valor); ?></td>
									<?php if($project->fase1ok == '1'): ?>
										<td><span class="badge badge-success" style="font-size: 14px;"> <?php echo e($project->fase1); ?>% </span></td>
									<?php else: ?>
										<td><span class=""><?php echo e($project->fase1); ?>%</span></td>
									<?php endif; ?>
									<?php if($project->fase2ok == '1'): ?>
										<td><span class="badge badge-success" style="font-size: 14px;"> <?php echo e($project->fase2); ?>% </span></td>
									<?php else: ?>
										<td><span class=" "><?php echo e($project->fase2); ?>%</span></td>
									<?php endif; ?>
									<?php if($project->fase3ok == '1'): ?>
										<td><span class="badge badge-success" style="font-size: 14px;"> <?php echo e($project->fase3); ?>% </span></td>
									<?php else: ?>
										<td><span class=" "><?php echo e($project->fase3); ?>%</span></td>
									<?php endif; ?>
									<?php if($project->fase1ok == '1' || $project->fase2ok == '1' || $project->fase3ok == '1' ): ?>
										<td><span class="badge badge-success" style="font-size: 14px;"> <?php echo e($project->totfases); ?> </span></td>
									<?php else: ?>
										<td><span class=" "><?php echo e($project->totfases); ?></span></td>
									<?php endif; ?>
									<td><span class=""><b><?php echo e($project->partfinal_p); ?></b></span></td>
									<td class="text-right"><span ><b>$ <?php echo e($project->partfinal); ?></b></span></td>
								</tr>
								<?php $totpart = $totpart + floatval(str_replace('.','',$project->valor)) ?>
								<?php $sum = $sum + floatval(str_replace('.','',$project->partfinal)) ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr class="text-white bg-secondary">
								<td colspan="" class="text-left"><span ><b>TOTALES</b></span></td>
								<td colspan="3" class="text-right"><span ><b>$ <?php echo e(number_format($totpart)); ?></b></span></td>
								<td colspan="6" class="text-right"><span ><b>$ <?php echo e(number_format($sum)); ?></b></span></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/projects/index.blade.php ENDPATH**/ ?>