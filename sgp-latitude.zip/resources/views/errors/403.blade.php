@extends('errors::layout')

@section('title', '403')
@section('message', 'Acceso no Autorizado')

@section('content')
	
@endsection