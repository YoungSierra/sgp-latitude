

<?php $__env->startSection('image'); ?>
	<img src="<?php echo e(asset('svg/error-404.svg')); ?>" class="img-fluid" alt="imagen error 404">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', __('404')); ?>
<?php $__env->startSection('body-title', 'Página no encontrada'); ?>
<?php $__env->startSection('text', __('Lo sentimos, no podemos encontrar la página que busca. Por favor verifique la dirección introducida, inténtelo de nuevo o regresa al Dashboard.')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/errors/404.blade.php ENDPATH**/ ?>