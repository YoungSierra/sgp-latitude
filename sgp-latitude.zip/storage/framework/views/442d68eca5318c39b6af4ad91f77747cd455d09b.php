<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name')); ?></title>
        <?php echo $__env->make('partials.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--  App CSS (Do not remove) -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    </head>
    <body class="c-app">
        <?php echo $__env->make('partials.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="c-wrapper" id="app">
            <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="c-body">
                <main class="c-main pt-3 fade-in">
                    <div class="container-fluid px-3">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </main>
            </div>
            <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- App JS (Do not remove) -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/functions.js')); ?>"></script>
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        <script>
        if(window.location.pathname.includes('projects') && document.getElementById('chartContainer1')){
            window.onload = function() {
                
                var chart1 = new CanvasJS.Chart("chartContainer1", {
                    animationEnabled: true,
                    title: {
                        text: "COSTOS GESTORA"
                    },
                    subtitles: [{
                        text: ""
                    }],
                    data: [{
                        type: "pie",
                        yValueFormatString: "#,##0.00\"%\"",
                        indexLabel: "{label} ({y})",
                        dataPoints: <?php  echo json_encode(isset($dataPoints1) ? $dataPoints1 : [], JSON_NUMERIC_CHECK); ?>
                    }]
                });
                chart1.render();
                

                var chart2 = new CanvasJS.Chart("chartContainer2", {
                    animationEnabled: true,
                    theme: "light2",
                    title:{
                        text: "COSTOS FIJOS PLATAFORMA"
                    },
                    axisY: {
                        title: ""
                    },
                    data: [{
                        type: "column",
                        yValueFormatString: "$ #,##0.## ",
                        dataPoints: <?php echo json_encode(isset($dataPoints2) ? $dataPoints2 : [], JSON_NUMERIC_CHECK); ?>
                    }]
                });
                chart2.render();

                var chart3 = new CanvasJS.Chart("chartContainer3", {
                    animationEnabled: true,
                    title: {
                        text: "GESTORA PARTICIPANTES"
                    },
                    subtitles: [{
                        text: ""
                    }],
                    data: [{
                        type: "pie",
                        yValueFormatString: "#,##0.00\"%\"",
                        indexLabel: "{label} ({y})",
                        dataPoints: <?php  echo json_encode(isset($dataPoints3) ? $dataPoints3 : [], JSON_NUMERIC_CHECK); ?>
                    }]
                });
                chart3.render();
                

                var chart4 = new CanvasJS.Chart("chartContainer4", {
                    animationEnabled: true,
                    theme: "light2",
                    title:{
                        text: "RELACIONES CORPORATIVAS"
                    },
                    axisY: {
                        title: ""
                    },
                    data: [{
                        type: "column",
                        yValueFormatString: "$ #,##0.## ",
                        dataPoints: <?php echo json_encode(isset($dataPoints4) ? $dataPoints4 : [], JSON_NUMERIC_CHECK); ?>
                    }]
                });
                chart4.render();
              
            }   
        }             
        </script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/layouts/app.blade.php ENDPATH**/ ?>