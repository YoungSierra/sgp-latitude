<div class="card text-white bg-dark">
	<div class="card-body h-100">
		<div class="row align-items-center h-100">
			<i class="fas fa-server fa-7x text-white mx-auto"></i>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/partials/logo_company.blade.php ENDPATH**/ ?>