<footer class="c-footer">
    <div>
        <i class="fas fa-copyright" aria-hidden="true"></i> Todos los derechos reservados <a href="https://lattitude.co/" target="_blank"><strong>Latittude</strong></a> - 2021
    </div>
</footer><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/partials/footer.blade.php ENDPATH**/ ?>