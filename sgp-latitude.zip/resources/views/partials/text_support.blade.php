<p class="text-center mt-3">
    Si tienes problemas para iniciar sesión, comunícate con el administrador general - <strong>email@latitude.com</strong>
</p>