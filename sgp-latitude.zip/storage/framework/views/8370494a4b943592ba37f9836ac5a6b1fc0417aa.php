<div class="c-sidebar c-sidebar-fixed c-sidebar-lg-show c-sidebar-minimized" id="sidebar">
    <div class="c-sidebar-brand bg-white d-lg-down-none">
		<img src="<?php echo e(asset('img/brand-full.png')); ?>" alt="Logo Lattitude" class="c-sidebar-brand-full w-50 mx-auto">
        <img src="<?php echo e(asset('img/brand-minimized.png')); ?>" alt="Logo Lattitude" class="c-sidebar-brand-minimized w-50 mx-auto">
    </div>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button class="c-sidebar-minimizer c-class-toggler"
    	type="button" data-target="_parent"
     	data-class="c-sidebar-minimized"
    ></button>
</div><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/partials/aside.blade.php ENDPATH**/ ?>