

<?php $__env->startSection('breadcrumbs', Breadcrumbs::render()); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(auth()->check() && auth()->user()->hasRole('superadministrador')): ?>
                        <?php echo e(__('Hello, Super Admin you are logged in!')); ?>

                    <?php endif; ?>

                    <?php if(auth()->check() && auth()->user()->hasRole('administrador')): ?>
                        <?php echo e(__('You aren´t Super Admin but, but you are an Admin logged in! :)')); ?>

                    <?php endif; ?>

                    <?php if(auth()->check() && auth()->user()->hasRole('asociado')): ?>
                        <?php echo e(__('You aren´t Super Admin but, but you are an Asociado logged in! :)')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sgp-latitude\resources\views/home.blade.php ENDPATH**/ ?>